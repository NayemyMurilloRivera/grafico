import { useMemo, useState } from 'react';
import { courses, universities, pathLevels, questions, resources } from './data.js';

const NAV = [
  ['cursos','📚','Cursos'],['examen','📝','Examen'],['camino','🗺️','Camino'],['desempeno','📊','Desempeño'],['recursos','🎒','Recursos']
];

const getSaved = (key, fallback) => {
  try { const value = localStorage.getItem(key); return value ? JSON.parse(value) : fallback; }
  catch { return fallback; }
};
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));

export default function App(){
  const [started,setStarted] = useState(()=>getSaved('cachimdia-v4-started',false));
  const [section,setSection] = useState(()=>getSaved('cachimdia-v4-section','cursos'));
  const [points,setPoints] = useState(()=>getSaved('cachimdia-v4-points',240));
  const [streak,setStreak] = useState(()=>getSaved('cachimdia-v4-streak',4));
  const [completed,setCompleted] = useState(()=>getSaved('cachimdia-v4-completed',[1,2]));
  const [university,setUniversity] = useState(()=>getSaved('cachimdia-v4-university','unsa'));
  const [toast,setToast] = useState('');

  const persist=(setter,key)=>(value)=>{ setter(prev=>{ const next=typeof value==='function'?value(prev):value; save(key,next); return next; }); };
  const go=persist(setSection,'cachimdia-v4-section');
  const notify=(t)=>{setToast(t);setTimeout(()=>setToast(''),2200)};

  if(!started){
    return <Splash onStart={()=>{setStarted(true);save('cachimdia-v4-started',true)}}/>;
  }

  return <div className="phone">
    <TopBar streak={streak} points={points} onHome={()=>go('cursos')}/>
    <main className="screen">
      {section==='cursos' && <Courses points={points} completed={completed} go={go}/>} 
      {section==='examen' && <Exam onDone={(score)=>{persist(setPoints,'cachimdia-v4-points')(p=>p+score); if(score>=60){persist(setStreak,'cachimdia-v4-streak')(s=>s+1); persist(setCompleted,'cachimdia-v4-completed')(c=>[...new Set([...c,Math.min(8,c.length+1)])]);} notify(score>=60?`¡Muy bien! +${score} puntos`:'Paddy dice: otra vez, tú puedes 💪')}}/>}
      {section==='camino' && <Path completed={completed} university={university} setUniversity={(id)=>{setUniversity(id);save('cachimdia-v4-university',id)}} onExam={()=>go('examen')}/>} 
      {section==='desempeno' && <Performance points={points} streak={streak} completed={completed.length}/>} 
      {section==='recursos' && <Resources notify={notify}/>} 
    </main>
    <BottomNav section={section} go={go}/>
    {toast && <div className="toast">{toast}</div>}
  </div>
}

function Splash({onStart}){
  return <div className="splash">
    <div className="splash-photo"/>
    <div className="splash-shade"/>
    <div className="splash-content">
      <img className="splash-logo" src="/assets/cachimdia-logo.png" alt="CachimdIA"/>
      <div className="splash-copy">
        <span className="paper-tag">SECUNDARIA + PREUNIVERSITARIO</span>
        <h1>Tu camino empieza aquí.</h1>
        <p>Aprende con Paddy, practica y prepárate para ingresar a la universidad.</p>
      </div>
      <button className="duo-btn primary" onClick={onStart}>Iniciar <b>→</b></button>
      <button className="duo-btn ghost" onClick={onStart}>Ya tengo progreso</button>
    </div>
  </div>
}

function TopBar({streak,points,onHome}){
  return <header className="topbar">
    <button className="brand" onClick={onHome}>
      <img src="/assets/cachimdia-logo.png" alt="Logo"/>
      <span><b>CachimdIA</b><small>Prepárate para tu futuro</small></span>
    </button>
    <div className="topstats"><span>🔥 {streak}</span><span>⭐ {points}</span></div>
  </header>
}

function Courses({points,completed,go}){
  const progress=Math.min(100,Math.round(completed.length/pathLevels.length*100));
  return <>
    <section className="home-hero">
      <div className="hero-copy"><div className="avatar"><img src="/assets/paddy-saluda.png" alt="Paddy"/></div><div><h2>¡Hola, cachimbo!</h2><p>¿Qué quieres aprender hoy?</p></div></div>
      <div className="hero-paddy"><img src="/assets/paddy-wave.gif" alt="Paddy saludando"/><div className="speech">Aprende,<br/>juega y<br/>avanza conmigo</div></div>
    </section>

    <section className="course-grid">
      {courses.map(c=><button key={c.id} className={`course-tile ${c.color}`} onClick={()=>go('examen')}>
        <span className="course-icon">{c.icon}</span><b>{c.title}</b><img src={c.paddy} alt="Paddy"/>
      </button>)}
    </section>

    <section className="progress-card">
      <div className="progress-title"><span>⭐</span><div><b>Nivel {Math.max(1,Math.floor(points/100))}</b><small>{progress}% del camino</small></div><button onClick={()=>go('camino')}>Ver camino</button></div>
      <div className="bar"><i style={{width:`${progress}%`}}/></div>
    </section>

    <section className="peru-strip">
      <img src="/assets/scene-emoliente.png" alt="Paddy con emoliente"/><div><b>Reto peruano del día</b><p>Resuelve 5 preguntas y gana estrellas.</p></div><button onClick={()=>go('examen')}>Ir →</button>
    </section>
  </>
}

function Exam({onDone}){
  const [index,setIndex]=useState(0); const [selected,setSelected]=useState(null); const [checked,setChecked]=useState(false); const [correct,setCorrect]=useState(0); const [done,setDone]=useState(false);
  const q=questions[index]; const pct=Math.round((index+1)/questions.length*100);
  const check=()=>{ if(selected===null)return; setChecked(true); if(selected===q.answer)setCorrect(v=>v+1); };
  const next=()=>{ if(!checked)return; if(index===questions.length-1){setDone(true);const finalCorrect=correct; const adjusted=selected===q.answer?correct:correct; onDone(Math.round(adjusted/questions.length*100));} else {setIndex(i=>i+1);setSelected(null);setChecked(false);} };
  if(done){const score=Math.round(correct/questions.length*100); return <section className="celebration"><div className="confetti">✦ ⭐ ✦</div><img src="/assets/paddy-victoria.png" alt="Paddy celebrando"/><h1>{score>=60?'¡Muy bien!':'¡Casi!'}</h1><p>Completaste la actividad</p><div className="reward">⭐ + {score} puntos</div><button className="duo-btn primary" onClick={()=>{setIndex(0);setSelected(null);setChecked(false);setCorrect(0);setDone(false)}}>Practicar otra vez →</button></section>}
  return <section className="exam-screen">
    <div className="exam-top"><button className="back">‹</button><div className="exam-bar"><i style={{width:`${pct}%`}}/></div><b>{index+1}/{questions.length}</b></div>
    <h1>{q.q}</h1>
    <div className="question-paddy"><img src={index%2?'/assets/paddy-pensando.png':'/assets/paddy-sorprendido.png'} alt="Paddy"/></div>
    <div className="answers">{q.opts.map((o,i)=><button key={o} className={`answer ${selected===i?'selected':''} ${checked&&i===q.answer?'correct':''} ${checked&&selected===i&&i!==q.answer?'wrong':''}`} onClick={()=>!checked&&setSelected(i)}><span>{selected===i?'●':'○'}</span>{o}</button>)}</div>
    {checked&&<div className={`feedback ${selected===q.answer?'good':'bad'}`}><b>{selected===q.answer?'¡Correcto!':'Revisemos'}</b><p>{q.why}</p></div>}
    {!checked?<button className="duo-btn primary" disabled={selected===null} onClick={check}>Comprobar</button>:<button className="duo-btn primary" onClick={next}>{index===questions.length-1?'Ver resultado':'Siguiente →'}</button>}
  </section>
}

function CampusCard({u,active,onClick}){
  return <button className={`campus ${u.tone} ${active?'active':''}`} onClick={onClick}><div className="building"><span className="roof"/><span className="tower">▥</span><span className="base"><i/><i/><i/></span></div><b>{u.short}</b><small>{u.city}</small></button>
}

function Path({completed,university,setUniversity,onExam}){
  return <section className="path-screen">
    <div className="path-hero"><div><span className="paper-tag">TU META</span><h1>Camino a la universidad</h1><p>Elige una meta y avanza nivel por nivel con Paddy.</p></div><img src="/assets/paddy-caminando.png" alt="Paddy caminando"/></div>
    <div className="campus-row">{universities.map(u=><CampusCard key={u.id} u={u} active={university===u.id} onClick={()=>setUniversity(u.id)}/>)}</div>
    <div className="route-stage">
      <div className="misti"/><div className="route-line"/>
      {pathLevels.map((l,idx)=>{const status=completed.includes(l.id)?'done':l.id===Math.max(...completed,0)+1?'open':'locked'; return <div key={l.id} className={`route-node n${idx+1} ${status}`}><button disabled={status==='locked'} onClick={()=>status==='open'&&onExam()}>{status==='done'?'✓':status==='locked'?'🔒':l.icon}</button><div className="route-label"><small>{l.place}</small><b>{l.title}</b><span>{l.subject}</span></div></div>})}
      <img className="walking-paddy" src="/assets/paddy-caminando.png" alt="Paddy en el camino"/>
    </div>
    <div className="fun-scene"><img src="/assets/scene-mototaxi.png" alt="Paddy en mototaxi"/><div><b>¡Paddy ya tomó su mototaxi!</b><p>Tú sigue avanzando al siguiente reto 😄</p></div></div>
  </section>
}

function Performance({points,streak,completed}){
  return <section className="performance">
    <div className="performance-hero"><img src="/assets/paddy-victoria.png" alt="Paddy feliz"/><div><span className="paper-tag">TU PROGRESO</span><h1>¡Vas avanzando!</h1><p>Paddy está orgulloso de tu esfuerzo.</p></div></div>
    <div className="stats-grid"><article><span>⭐</span><b>{points}</b><small>Puntos</small></article><article><span>🔥</span><b>{streak}</b><small>Días de racha</small></article><article><span>🏁</span><b>{completed}</b><small>Niveles</small></article><article><span>🎯</span><b>{Math.round(completed/pathLevels.length*100)}%</b><small>Camino</small></article></div>
    <div className="mural"><img src="/assets/scene-explorando.png" alt="Paddy explorando Arequipa"/><div className="mural-copy"><b>Tu esfuerzo cuenta</b><p>Un nivel cada día te acerca a tu meta.</p></div></div>
  </section>
}

function Resources({notify}){
  return <section className="resources"><div className="resource-hero"><img src="/assets/paddy-tablet.png" alt="Paddy con tablet"/><div><span className="paper-tag">RECURSOS</span><h1>Tu mochila de estudio</h1><p>Material ligero para estudiar incluso con poca conexión.</p></div></div>
  <div className="resource-grid">{resources.map(r=><button key={r.title} onClick={()=>notify(`${r.title}: listo para conectar al backend`)}><div className="res-img"><img src={r.paddy} alt="Paddy"/></div><span>{r.icon}</span><div><b>{r.title}</b><small>{r.meta}</small></div><i>→</i></button>)}</div>
  <div className="fun-scene"><img src="/assets/scene-combi.png" alt="Paddy en combi"/><div><b>Modo rural</b><p>Recursos descargables y prácticas cortas para estudiar donde estés.</p></div></div></section>
}

function BottomNav({section,go}){return <nav className="bottom-nav">{NAV.map(([id,icon,label])=><button key={id} className={section===id?'active':''} onClick={()=>go(id)}><span>{icon}</span><small>{label}</small></button>)}</nav>}
