export const courses = [
  { id:'lectura', title:'Lectura', icon:'📖', color:'coral', subtitle:'Comprensión y razonamiento verbal', progress:62, paddy:'/assets/paddy-leyendo.png' },
  { id:'mate', title:'Matemáticas', icon:'➗', color:'blue', subtitle:'Aritmética, álgebra y razonamiento', progress:48, paddy:'/assets/paddy-pensando.png' },
  { id:'ciencia', title:'Ciencia', icon:'💡', color:'yellow', subtitle:'Física, química y biología', progress:35, paddy:'/assets/paddy-descubriendo.png' },
  { id:'sociales', title:'Mundo', icon:'🌎', color:'green', subtitle:'Historia, geografía y ciudadanía', progress:54, paddy:'/assets/paddy-estudiando.png' },
];

export const universities = [
  { id:'unsa', short:'UNSA', name:'Universidad Nacional de San Agustín', city:'Arequipa', tone:'brick' },
  { id:'ucsm', short:'UCSM', name:'Universidad Católica de Santa María', city:'Arequipa', tone:'blue' },
  { id:'ucsp', short:'UCSP', name:'Universidad Católica San Pablo', city:'Arequipa', tone:'stone' },
];

export const pathLevels = [
  { id:1, title:'Bases numéricas', subject:'Matemática', place:'Costa', icon:'➕' },
  { id:2, title:'Lectura veloz', subject:'Comunicación', place:'Valle', icon:'📚' },
  { id:3, title:'Razonamiento', subject:'Matemática', place:'Sierra', icon:'🧠' },
  { id:4, title:'Ciencia diaria', subject:'Ciencia', place:'Arequipa', icon:'🧪' },
  { id:5, title:'Historia del Perú', subject:'Sociales', place:'Cusco', icon:'🏛️' },
  { id:6, title:'Álgebra', subject:'Matemática', place:'Misti', icon:'✖️' },
  { id:7, title:'Comprensión', subject:'Comunicación', place:'Altiplano', icon:'📝' },
  { id:8, title:'Simulacro', subject:'Mixto', place:'Universidad', icon:'🎓' },
];

export const questions = [
  { q:'Si 3 cuadernos cuestan S/ 18, ¿cuánto cuestan 5 cuadernos?', opts:['S/ 24','S/ 28','S/ 30','S/ 36'], answer:2, why:'Cada cuaderno cuesta S/ 6; 5 × 6 = S/ 30.' },
  { q:'¿Cuál es la idea principal de un texto?', opts:['Un ejemplo secundario','La información central','La última oración','Una palabra difícil'], answer:1, why:'La idea principal organiza y resume el contenido central.' },
  { q:'¿Qué cambio de estado ocurre cuando el agua pasa de líquido a vapor?', opts:['Condensación','Solidificación','Evaporación','Fusión'], answer:2, why:'El paso de líquido a gas es evaporación.' },
  { q:'¿En qué continente se encuentra el Perú?', opts:['Asia','América del Sur','Europa','África'], answer:1, why:'Perú se encuentra en América del Sur.' },
  { q:'Resuelve: 2x + 6 = 16', opts:['x=3','x=4','x=5','x=8'], answer:2, why:'2x = 10, entonces x = 5.' },
];

export const resources = [
  { title:'Fórmulas de Matemática', meta:'PDF · 12 páginas', icon:'📘', paddy:'/assets/paddy-tablet.png' },
  { title:'Comprensión lectora', meta:'Ficha offline', icon:'📄', paddy:'/assets/paddy-leyendo.png' },
  { title:'Banco de admisión', meta:'50 preguntas', icon:'🧠', paddy:'/assets/paddy-estudiando.png' },
  { title:'Repaso de Historia', meta:'Audio · 8 min', icon:'🎧', paddy:'/assets/paddy-pensando.png' },
];
